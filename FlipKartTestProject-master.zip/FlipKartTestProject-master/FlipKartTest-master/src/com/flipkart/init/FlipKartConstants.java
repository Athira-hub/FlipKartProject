package com.flipkart.init;

public class FlipKartConstants {

	public String TestFile = "./testdata.txt";
	public String baseUrl = "https://www.flipkart.com/";

}
