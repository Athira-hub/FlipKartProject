package com.flipkart.test;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.flipkart.init.LaunchBrowser;
import com.flipkart.pageobject.Login;
import com.flipkart.pageobject.Logout;
import com.flipkart.pageobject.PlaceOrder;

public class FlipKartTest extends LaunchBrowser {

	Login login;
	Logout logout;
	PlaceOrder placeOrder;
	
	public FlipKartTest() throws Exception {
		login = new Login();
		logout = new Logout();
		placeOrder = new PlaceOrder();

	}

	/**
	 * This method is to select a product through flipkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@Test(priority=2)
	public void flipkartSelectOrder() throws Exception {

		System.out.println("Starting with FlipKart Test Scenarios");
		// Selecting product
		placeOrder.selectProduct();
		
	}
	
	/**
	 * This method is to login to the filpkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@Test(priority=1)
	public void loginTest() throws Exception {
		login.doLogin();
		Thread.sleep(1000);

	}
	
	/**
	 * This method is to purchase a product through flipkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@Test(priority=3)
	public void flipkartOrderCheckout() throws Exception {

		// Verify and Purchase product
		placeOrder.verifyAndPurchaseProduct();

	}

	/**
	 * This method is to read input values from text file. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@BeforeSuite
	public void readValues() throws Exception {
		readValuesFromFile();
	}

	/**
	 * This method is to launch browser according to user input. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@BeforeTest
	public void launchBrowser() throws Exception {
		doLaunchBrowser();

	}

	/**
	 * This method is to logout from flipkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@AfterTest
	public void logoutTest() throws Exception {
		logout.doLogout();

	}

}
