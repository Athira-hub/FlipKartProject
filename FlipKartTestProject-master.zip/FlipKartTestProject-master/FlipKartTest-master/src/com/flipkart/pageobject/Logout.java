package com.flipkart.pageobject;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.flipkart.init.LaunchBrowser;
import com.flipkart.init.ReportingConstants;
import com.flipkart.objrepo.FLIPKARTOBJREPO;

public class Logout extends LaunchBrowser {

	ReportingConstants reportingConstants;
	public WebDriver driver;
	FLIPKARTOBJREPO flipkartobjrepo;

	public Logout() throws IOException {
		reportingConstants = new ReportingConstants();
		flipkartobjrepo = new FLIPKARTOBJREPO();
	}

	/**
	 * This method is to logout from the flipkart application Creator
	 * athira.sasidharan<08/20/2019>
	 **/

	public void doLogout() throws Exception {
		
		driver=LaunchBrowser.driver;
		FLIPKARTOBJREPO pageObj=PageFactory.initElements(driver, FLIPKARTOBJREPO.class);
		// Navigate to FlipKart Home page
		pageObj.FlipkartHome.click();
		Actions actions = new Actions(driver);
		WebElement myAcctName = pageObj.MyAccount;
		actions.moveToElement(myAcctName).perform();
		// Click on Logout
		pageObj.LogOutLink.click();
		Thread.sleep(2000);

		System.out.println("Logout is successful");
		Assert.assertTrue(reportingConstants.TRUE);
		driver.close();
		driver.quit();

	}
}
