package com.flipkart.pageobject;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.flipkart.init.LaunchBrowser;
import com.flipkart.init.ReportingConstants;
import com.flipkart.objrepo.FLIPKARTOBJREPO;

public class PlaceOrder extends LaunchBrowser{

	ReportingConstants reportingConstants;
	public WebDriver driver;
	public String itemName;
	FLIPKARTOBJREPO flipkartobjrepo;
	
	public PlaceOrder() throws IOException {
		reportingConstants = new ReportingConstants();
		flipkartobjrepo = new FLIPKARTOBJREPO();
		
	}

	/**
	 * This method is to select a product after login Creator
	 * athira.sasidharan<08/20/2019>
	 **/
	public void selectProduct() throws Exception {

		driver = LaunchBrowser.driver;
		FLIPKARTOBJREPO pageObj=PageFactory.initElements(driver, FLIPKARTOBJREPO.class);
		// Search for an item in the search textbox
		pageObj.InputItem.sendKeys(LaunchBrowser.itemName);
		pageObj.InputItem.sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		// Select the required item from the list displayed
		WebElement element = pageObj.SelectedItem;
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		// Navigate to the search result page
		pageObj.ItemLink.click();
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));

		System.out.println("Product selected..." + reportingConstants.PASS);
		Assert.assertTrue(reportingConstants.TRUE);
	}

	/**
	 * This method is to Get information such as Name,Price and Description about
	 * the item from Search Page,Compare with checkout page and Purchase Creator
	 * athira.sasidharan<08/20/2019>
	 **/
	public void verifyAndPurchaseProduct() throws Exception {

		driver = LaunchBrowser.driver;
		FLIPKARTOBJREPO pageObj=PageFactory.initElements(driver, FLIPKARTOBJREPO.class);
		// Get information such as Name,Price and Description about the item from Search
		// Page
		WebElement itemNameDescFromSearch = pageObj.ItemNameDescFromSearchPage;
		Thread.sleep(1000);
		String itemNameFromSearchPage = itemNameDescFromSearch.getText();
		WebElement itemPriceFromSearch = pageObj.ItemPriceFromSearch;
		String itemPriceFromSearchPage = itemPriceFromSearch.getText();
		// Scroll and Click on Add to Cart button
		WebElement addToCart = pageObj.AddToCartBtn;
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
		Thread.sleep(500);
		addToCart.click();

		// Get information such as Name,Price and Description about the item from
		// Checkout Page
		WebElement itemNameFromCheckout = pageObj.ItemNameFromCheckout;
		String itemNameFromCheckoutPage = itemNameFromCheckout.getText();
		WebElement itemPriceFromCheckout = pageObj.ItemPriceFromCheckout;
		String itemPriceFromCheckoutPage = itemPriceFromCheckout.getText();
		WebElement itemDescFromCheckout = pageObj.ItemDescFromCheckout;
		String itemDescFromCheckoutPage = itemDescFromCheckout.getText();

		// Compare and verify the information of Search and Checkout page are same
		Assert.assertTrue(itemNameFromSearchPage.contains(itemNameFromCheckoutPage));
		Assert.assertTrue(itemNameFromSearchPage.contains(itemDescFromCheckoutPage));
		Assert.assertTrue(itemPriceFromSearchPage.contains(itemPriceFromCheckoutPage));

		// Place Order
		pageObj.PlaceOrderBtn.click();
		Thread.sleep(5000);
	}

}
