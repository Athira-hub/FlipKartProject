package com.flipkart.objrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class FLIPKARTOBJREPO {
	
	// Login Objects
	@FindBy(how=How.XPATH,using="//input[@class='_2zrpKA _1dBPDZ']")
	public WebElement UserName;
	@FindBy(xpath="//input[@class='_2zrpKA _3v41xv _1dBPDZ']")
	public WebElement Password;
	@FindBy(xpath="//button[@class='_2AkmmA _1LctnI _7UHT_c']")
	public WebElement LoginBtn;

	
	//Logout Objects
	@FindBy(how=How.XPATH,using="//img[@alt='Flipkart']")
	public WebElement FlipkartHome;
	@FindBy(how=How.XPATH,using="//div[@class='_2aUbKa']")
	public WebElement MyAccount;
	@FindBy(how=How.XPATH,using="//a[contains(.,'Logout')]")
	public WebElement LogOutLink;
	
	//Flipkart Objects
	
	@FindBy(how=How.XPATH,using="//input[@class='LM6RPg']")
	public WebElement InputItem;
	@FindBy(how=How.XPATH,using="//div[@class='_3wU53n']")
	public WebElement SelectedItem;
	@FindBy(how=How.XPATH,using="//div[@class='_3BTv9X']")
	public WebElement ItemLink;
	@FindBy(how=How.XPATH,using="//span[@class='_35KyD6']")
	public WebElement ItemNameDescFromSearchPage;
	@FindBy(how=How.XPATH,using="//div[@class='_1vC4OE _3qQ9m1']")
	public WebElement ItemPriceFromSearch;
	@FindBy(how=How.XPATH,using="//button[@class='_2AkmmA _2Npkh4 _2MWPVK']")
	public WebElement AddToCartBtn;
	@FindBy(how=How.XPATH,using="//a[@class='_325-ji _3ROAwx']")
	public WebElement ItemNameFromCheckout;
	@FindBy(how=How.XPATH,using="//span[@class='pMSy0p XU9vZa']")
	public WebElement ItemPriceFromCheckout;
	@FindBy(how=How.XPATH,using="//div[@class='v7-Wbf']")
	public WebElement ItemDescFromCheckout;
	@FindBy(how=How.XPATH,using="//*[@class='_2AkmmA iwYpF9 _7UHT_c']")
	public WebElement PlaceOrderBtn;
	
		
}
